package com.acc.sys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccomodationSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
