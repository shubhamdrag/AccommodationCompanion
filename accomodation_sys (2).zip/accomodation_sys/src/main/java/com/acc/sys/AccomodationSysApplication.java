package com.acc.sys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccomodationSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccomodationSysApplication.class, args);
	}

}
